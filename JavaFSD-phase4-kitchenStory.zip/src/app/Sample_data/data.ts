import { Food } from "../Models/food";
import { Tag } from "../Models/tag";

export const sample_foods: Food[] = [
    {
        id: '1',
        name: 'Milk',
        price: 25,
        imageUrl: 'assets/milk.jpeg',
        tags: ['Veg'],
        company: ''
    },
    {
        id: '2',
        name: 'Bread',
        price: 20,
        imageUrl: 'assets/foodItem2.jpg',
        tags: ['Veg'],
        company: ''

    },
    {
      id: '3',
      name: 'Onion',
      price: 40,
      imageUrl: 'assets/Onion1.jpeg',
      tags: ['veg'],
      company: ''
  },
  {
    id: '4',
    name: 'Turmeric Powder',
    price: 50,
    imageUrl: 'assets/turmeric.jpeg',
    tags: ['veg'],
    company: ''
},
{
  id: '5',
  name: 'Coriander Powder',
  price: 30,
  imageUrl: 'assets/coriander.jpeg',
  tags: ['veg'],
  company: ''
},
    {
        id: '6',
        name: 'Eggs',
        price: 10,
        imageUrl: 'assets/foodItem3.jpg',
        tags: ['Non-veg'],
        company: ''
    },
    {
        id: '7',
        name: 'Potatoes',
        price: 20,
        imageUrl: 'assets/foodItem4.jpg',
        tags: ['Veg'],
        company: ''
    },
    {
        id: '8',
        name: 'Chicken Meat',
        price: 250,
        imageUrl: 'assets/chicken3.jpeg',
        tags: ['Non-veg'],
        company: ''
    },
    {
        id: '9',
        name: 'Fish Meat',
        price: 200,
        imageUrl: 'assets/fish2.jpeg',
        tags: ['Non-veg'],
        company: ''
    },
    {
      id: '10',
      name: 'Butter',
      price: 30,
      imageUrl: 'assets/butter.jpeg',
      tags: ['veg'],
      company: ''
  },
  {
    id: '11',
    name: 'Mutton',
    price: 750,
    imageUrl: 'assets/mutton1.jpeg',
    tags: ['Non-veg'],
    company: ''
},
{
  id: '12',
  name: 'Wheat',
  price: 175,
  imageUrl: 'assets/wheat.jpeg',
  tags: ['veg'],
  company: ''
}
]

export const sample_tags: Tag[] = [

    {
        name: 'All',
        count: 12
    },
    {
        name: 'Veg',
        count: 8
    },
    {
        name: 'Non-veg',
        count: 4
    }
]
